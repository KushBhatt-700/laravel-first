<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserDetails;

class UserDetailsController extends Controller
{
    function userDataView(){
        $user_data = UserDetails::paginate(5);
        $data = compact('user_data');
        return view('user_data-view')->with($data);
    }

    function userDataForm(Request $request){
        return view('user-form');
    }
    
    function userDataSubmit(Request $request){
        $insertUserData = new UserDetails;
        $insertUserData->first_name = $request['first_name'];
        $insertUserData->last_name = $request['last_name'];
        $insertUserData->email = $request['email'];
        $insertUserData->password = $request['password'];
        $insertUserData->gender = $request['gender'];
        $insertUserData->age = $request['age'];
        $insertUserData->save();
        return redirect('user/data');
    }
}
