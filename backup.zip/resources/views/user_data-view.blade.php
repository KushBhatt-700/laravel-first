{{-- 
<div class="container mb-5 mt-5"> --}}
    <div id="pageTitle">
        <h2 class="d-flex justify-content-center">Welcome To Ajax Form</h2>
    </div>
    <div class="mt-4 mb-4">
        <div class="d-flex align-items-center">
            <form action="" id="formSubmit" class="d-flex col-md-4">
                <input type="search" name="search" class="form-control me-2" id="searchInput" placeholder="Search" aria-label="Search" value="#">
                <button class="btn btn-outline-success" type="submit">Search</button>
                <div class="mx-2">
                    <a href="#">
                        <button id="resetBtn" class="btn btn-outline-danger" type="button">Reset</button>
                    </a>
                </div>
            </form>
            <div class="resultOfInput"></div>
            {{-- <div class="ms-auto">
                <a href="{{ route('enquire.add') }}" class="btn btn-primary">Add Enquire</a>
            </div> --}}
        </div>
    </div>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Email</th>
                <th scope="col">Gender</th>
                <th scope="col">Age</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($user_data as $key => $items)
                <tr>
                    <td>{{ $items->user_id }}</td>
                    <td>{{ $items->first_name }}</td>
                    <td>{{ $items->last_name }}</td>
                    <td>{{ $items->email }}</td>
                    <td>{{ $items->gender }}</td>
                    <td>{{ $items->age }}</td>
                    <td> 
                        <a href="#"><button class="btn btn-danger">Delete</button></a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <div class="row mx-auto">
        {{ $user_data->links('layouts.pagination-links') }}
    </div>
{{-- </div> --}}