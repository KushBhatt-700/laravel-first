<!doctype html>
<html class="no-js" lang="en">
    @include('layouts.head')
	<body>
		@include('layouts.header_menu');
        <section id="service" class="service" style="padding: 0px 0 87px;">
            <div class="container">
                <div class="service-content">
                    <div class="row">
                        <div class="col-md-12">
                                {!! Form::open([
                                    'url' => '/user/form',
                                    'method' => 'post',
                                    'class' => 'row g-3',
                                ]) !!}
                                    @csrf
                                    <div class="col-12">
                                        <p class="h1 text-primary text-center">User Detail Form</p>
                                    </div>
                                    <div class="col-12">
                                        <label for="inputFirstName" class="form-label">First Name</label>
                                        {!! Form::text('first_name', null, ['class' => 'form-control', 'id' => 'inputFirstName', 'placeholder' => 'First Name']) !!}
                                        {{-- <span class="text-danger">
                                            @error('first_name')
                                                {{$message}}
                                            @enderror
                                        </span> --}}
                                    </div>
                                    <div class="col-12">
                                        <label for="inputLastName" class="form-label">Last Name</label>
                                        {!! Form::text('last_name', null, ['class' => 'form-control', 'id' => 'inputLastName', 'placeholder' => 'Last Name']) !!}
                                        {{-- <span class="text-danger">
                                            @error('last_name')
                                                {{$message}}
                                            @enderror
                                        </span> --}}
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail4" class="form-label">Email</label>
                                        <input type="email" name="email" class="form-control" id="inputEmail4" placeholder="Email" value="{{ old('email') }}">
                                        {{-- <span class="text-danger">
                                            @error('email')
                                                {{$message}}
                                            @enderror
                                        </span> --}}
                                    </div>
                                    <div class="col-md-12">
                                        <label for="inputPassword4" class="form-label">Password</label>
                                        <input type="password" name="password" class="form-control" id="inputPassword4" placeholder="Password">
                                        {{-- <span class="text-danger">
                                            @error('password')
                                                {{$message}}
                                            @enderror
                                        </span> --}}
                                    </div>
                                    <div class="form-group">
                                        <label for="inputGender" class="form-label">Gender</label>
                                        {!! Form::select(
                                            'gender',
                                            [
                                                'M' => 'Male',
                                                'F' => 'Female',
                                                'O' => 'Other'
                                        ],
                                        null,
                                        [
                                            'class' => 'form-control',
                                            'id' => 'inputGender'
                                        ]
                                        ) !!}
                                        {{-- <input type="text" name="gender" class="form-control" id="inputGender"/> --}}
                                    </div>
                                    <div class="form-group">
                                        <label for="inputAge" class="form-label">Age</label>
                                        <input type="text" name="age" class="form-control" id="inputAge"/>
                                    </div>
                                    <div>
                                        <button id="formSubmitBtn" type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>	
                        </div>
                    </div>
                </div>
            </div>
        </section><!--/.welcome-hero-->
        <!--blog start -->
		<section id="blog" class="blog"></section><!--/.blog-->
		<!--blog end -->
		<section id="service" class="service">
        	@include('layouts.footer');
		</section>
		<script>
			$('#formSubmitBtn').mouseenter(function(){
				var $nameInput = $('#inputName').val();
				var $inputEmail4 = $('#inputEmail4').val();
				var $inputPassword4 = $('#inputPassword4').val();
				if($nameInput == '' || $inputEmail4 == '' || $inputPassword4 == ''){
					var $classCheck = $('#btnWrapId').hasClass('btnWrapClass');
					if($classCheck == true){
						$('#formSubmitBtn').unwrap();
					}else{
						$('#formSubmitBtn').wrap("<div class='btnWrapClass' id='btnWrapId' style='text-align: right'></div>");
					}
				}
			});
		</script>
        <script src="/assets/js/ajax_jquery.js"></script>
    </body>
</html>