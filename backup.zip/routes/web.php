<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TestController;
use App\Http\Controllers\ResourceController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\EnquireFormController;
use App\Http\Controllers\TranslatedPageController;
use App\Http\Controllers\GroupMemberData;
use App\Http\Controllers\UserDetailsController;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware(['grouped'])->group(function (){
    // Group middleware to check if user_role is administrator or age is grater then 18.
    Route::resource('/user-data', ResourceController::class);
    Route::get('/user-data/{id}', [ResourceController::class, 'show']);
});

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/demo/{name?}', function($name = null) {
//     $data = compact('name');
//     return view('demo')->with($data);
// });

Route::get('/demo', [TestController::class, 'index']);

Route::get('/sum/{first?}/{second?}', function($first = null, $second = null){
    $data = compact('first', 'second');
    return view('sum')->with($data);
    // $sum = $first+$second;
    // echo $first.'+'.$second.' = '.$sum; 
});

Route::group(["prefix" => 'enquire-form'], function(){
    Route::get('/', [EnquireFormController::class, 'index'])->name('enquire.add');
    Route::post('/', [EnquireFormController::class, 'store']);
    Route::get('/view', [EnquireFormController::class, 'view'])->name('enquireForm.view');
    Route::get('/delete/{id}', [EnquireFormController::class, 'delete'])->name('enquireForm.delete');
    Route::get('/edit/{id}', [EnquireFormController::class, 'edit'])->name('enquireForm.edit');
    Route::post('/update/{id}', [EnquireFormController::class, 'update'])->name('enquireForm.update');
});

Route::get('/user/data', [UserDetailsController::class, 'userDataView']);
Route::get('/user/form', [UserDetailsController::class, 'userDataForm']);
Route::post('/user/form', [UserDetailsController::class, 'userDataSubmit']);

Route::get('/jquery',function(){
    return view('my-jquery');
});

// One to One relation.
Route::get('/group-member-data', [GroupMemberData::class, 'index']);
// // One to Many relation. (To get Members by Groups)
Route::get('/member-data', [GroupMemberData::class, 'getGroupMembers']);

// Route check if user_is set or not in session else redirected on /no-access page using middleware (RouteSessionChecker).
Route::get('/translated-page/{lang?}', [TranslatedPageController::class, 'pageView'])->middleware('SessionChecker');
Route::get('/no-access', function(){
    echo "You are not allowed to access this page.";
});

Route::get('/get-all-session', function (){
    $session = session()->all();
    p($session);
    die;
});
Route::get('/login', function(){
    session(['user_id' => '1', 'user_name' => 'kushbhatt', 'user_roll' => 'administrator']);
    return redirect()->back();
    // return "User logged-in successfully.";
});
Route::get('/logout', function(){
    session()->forget(['user_id', 'user_name']);
    return redirect()->back();
});